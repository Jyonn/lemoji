from .emoji_v1_0 import EMOJI_LIST as EMOJI_LIST_1_0
from .emoji_v2_0 import EMOJI_LIST as EMOJI_LIST_2_0
from .emoji_v3_0 import EMOJI_LIST as EMOJI_LIST_3_0
from .emoji_v4_0 import EMOJI_LIST as EMOJI_LIST_4_0
from .emoji_v5_0 import EMOJI_LIST as EMOJI_LIST_5_0
from .emoji_v11_0 import EMOJI_LIST as EMOJI_LIST_11_0
from .emoji_v12_0 import EMOJI_LIST as EMOJI_LIST_12_0
from .emoji_v12_1 import EMOJI_LIST as EMOJI_LIST_12_1
from .emoji_v13_0 import EMOJI_LIST as EMOJI_LIST_13_0
from .emoji_v13_1 import EMOJI_LIST as EMOJI_LIST_13_1
from .emoji_v14_0 import EMOJI_LIST as EMOJI_LIST_14_0
from .emoji_v15_0 import EMOJI_LIST as EMOJI_LIST_15_0


EMOJI_LIST = EMOJI_LIST_15_0
